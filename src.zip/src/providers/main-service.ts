export class MainService{
  public static lang :string='en';
  public static baseUrl : string = "http://104.236.61.15/api/";
  public static imageUrl : string = "http://104.236.61.15/";
}
