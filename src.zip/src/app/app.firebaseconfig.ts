export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyCoLfwGr8am4X6U1hZPzQtPAswSwFUaYoU",
  authDomain: "anyservice-66cb0.firebaseapp.com",
  databaseURL: "https://anyservice-66cb0.firebaseio.com",
  projectId: "anyservice-66cb0",
  storageBucket: "anyservice-66cb0.appspot.com",
  messagingSenderId: "34895082223"
};
